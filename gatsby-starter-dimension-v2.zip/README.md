# gatsby-starter-dimension

**This is a starter for Gatsby.js V2.**

**The older V1 version of this starter can be found on the v1 branch:**

Gatsby.js V2 starter based on the Dimension site template, designed by HTML5 UP. Check out https://codebushi.com/gatsby-starters/ for more Gatsby starters and templates.

## Preview

https://gatsby-dimension.surge.sh/

## Installation

Install this starter (assuming Gatsby is installed) by running from your CLI:
<br/>
`gatsby new gatsby-starter-dimension https://github.com/codebushi/gatsby-starter-dimension`

Run `gatsby develop` in the terminal to start the dev site.